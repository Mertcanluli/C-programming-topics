#include<iostream>

using namespace std;

// Kullanıcıdan girilen 5 değerin ortalamasını alan kodu yazınız.

int main()
{
    int toplam=0; // toplam değişkeninin for dışında tanımlanması lazımdır. Çünkü döngü her işlmeden sonra toplam değerini sıfırlar ve toplam yapamaz.

    for(int i=0; i<5; i++)
    {
        int okunan;
        cout<<"Lutfen Sayi giriniz: "<<endl;
        cin>>okunan;
        toplam+=okunan; // toplam= toplam+okunan
    }

    cout<<"Ortalama: "<< toplam/5 <<endl;

    return 0;
}