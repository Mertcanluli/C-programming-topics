#include<iostream>

using namespace std;

int main()
{

    // yıldızlar ile ters dik üçgen yapımı.

    cout<<"Boyut Degerini Giriniz: "<<endl;
    int boyut;
    cin>>boyut;

    for(int i=1; i<=boyut; i++) // i değişkeni satır sayısını belirler.
    {
        for(int k=1; k<i; k++) // k değişkeni boşluk sayısını hesaplar.
        {
            cout<<" ";
        }
        for(int j=1; j<=boyut-i+1; j++) // j değişkeni yıldız sayısnı hesaplar.
        {
            cout<<"*";
        }
        cout<<endl;
    }

    return 0;
}