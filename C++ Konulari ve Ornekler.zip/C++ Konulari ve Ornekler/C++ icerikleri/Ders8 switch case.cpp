#include<iostream>

using namespace std;

int main()
{
    int a;
    
    a=2;

    switch(a)
    {
        case 1: cout<<"1"<<endl;
        break;

        case 2: cout<<"2"<<endl;
        break;

        case 3: cout<<"3"<<endl;

        default:
        cout<<"Diger Durumlar"<<endl;

    }

    return 0;
}