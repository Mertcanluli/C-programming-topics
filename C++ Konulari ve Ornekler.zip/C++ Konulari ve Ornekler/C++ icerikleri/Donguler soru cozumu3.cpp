#include<iostream>

using namespace std;

// Kullanıcı -1 girene kadar girilen tüm sayıların ortalamsını bulan kodu yazınız.

int main()
{
    int toplam=0;
    int sayi=0;
    int okunan=0;

    for(;;) // for döngüsünün bu formatı sonsuz döngü anlamına gelmektedir. !!!!!!!!!!
    {
        cout<<"Lutfen Sayi Giriniz: "<<endl;
        cin>>okunan;

        if(okunan==-1) // Eğer okunan değer -1 ise döngüyü kır.
          break;

        toplam= toplam+okunan;
        sayi++;  

    }

    cout<<"Toplam: " << toplam <<endl;
    cout<<"Sayi: " << sayi<< endl;
    cout<<"Ortalama: " << (float) toplam/sayi <<endl;

    return 0;
}

