#include<iostream>

using namespace std;

int f(int x)
{
    cout<< x << endl;
    return 5; // return geri döndürme yapar. Örneğin return 5 yazarsak main içindeki komutlardan sonra 5 yazar.
}

void g(int x) // void fonksiyonu herhangi bir değer döndürmesi yapmaz...
{
    cout<< x+5 << endl;
}

int main()
{
    cout<< f(15) << endl;
    cout<< f(19) << endl;
    g(5);

}