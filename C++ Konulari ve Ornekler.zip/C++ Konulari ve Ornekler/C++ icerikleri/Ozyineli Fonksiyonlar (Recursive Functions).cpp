#include<iostream>

using namespace std;

int faktoriyelr (int n)
{
    if(n==1)
    return 1;
    
    return n * faktoriyelr(n-1);

}

int main()
{
    cout << faktoriyelr(5) << endl;
}

// Recursive fonksiyonları aynı değişken ile yazılır.

// faktoriyelr(5)= 5 * faktoriyelr(4)
// faktoriyelr(4)= 4 * faktoriyelr(3)
// faktoriyelr(3)= 3 * faktoriyelr(2)
// faktoriyelr(2)= 2 * faktoriyelr(1)
// faktoriyelr(1)= 1 yapısı ile yapılır bu soru.  !!!!!!!!  ÖNEMLİ !!!!!!!!
