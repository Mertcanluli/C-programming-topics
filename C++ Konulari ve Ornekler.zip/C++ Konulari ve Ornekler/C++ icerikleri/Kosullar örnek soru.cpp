#include<iostream>

using namespace std;

int main()
{
    int x,y;

    cout<<"Lutfen Birinci Sayiyi Giriniz: "<<endl;
    cin>>x;

    cout<<"Lutfen Ikinci Sayiyi Giriniz: "<<endl;
    cin>>y;

    if(x==y)
    {
        cout<<"iki sayi esittir."<<endl;
    }
    else
    {
        cout<<"iki sayi esit degildir."<<endl;
    }
    if(x!=y)
    {
        cout<<"Sayilar farklidir."<<endl;
    }
    else
    {
        cout<<"Sayilar farkli degildir."<<endl;
    }
    if(x<y)
    {
        cout<<"Birinci sayi kucuktur."<<endl;
    }
    else
    {
        cout<<"Birinci sayi kucuk degildir"<<endl;
    }
    if(x>y)
    {
        cout<<"Ikinci sayi kucuktur."<<endl;
    }
    else
    {
        cout<<"Ikinci sayi kucuk degildir"<<endl;
    }
    if(x<=y)
    {
        cout<<"Birinci sayi kucuk esittir."<<endl;
    }
    else
    {
        cout<<"Birinci sayi kucuk esit degildir"<<endl;
    }
    if(x>=y)
    {
        cout<<"Ikinci sayi kucuk esittir."<<endl;
    }
    else
    {
        cout<<"Ikinci sayi kucuk esit degildir"<<endl;
    }

    return 0;
}