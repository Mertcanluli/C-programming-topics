#include<iostream>

using namespace std;




int main()
{
    // 1 den 100 e kadar olan tek sayıların ekrana bastırma. 1--> while 2-->for 3-->for ile yapıldı...

    /*int a;
    a=1;

    while(a<=100)
    {
        cout<<a<< ",";
        a+=2;
    
    }
    */
    
    


    int i;

    for(i=1;i<=100;i++)
    {
        if(i%2==1)
        {
            cout<<i<<",";
        }
    }
    

   /*int i;

   for(i=1;i<=100;i+=2)
   {
    cout<<i<<",";
   }
   */


  // 100 den 70 e kadar olan 7 ye tam bölünen sayıları ekrana bastırma kodu.

  /*int i;

  for(i=100; i>=70; i--)
  {
    if(i%7==0)
    {
        cout<<i<<",";
    }
  }
  */



 // 1 ile 100 arasındaki hem 3 e hem de 7 ye tam bölünen sayıların ekrana bastırma kodu.

 /*int i;

 for(i=1; i<=100; i++)
 {
    if(i%3==0 && i%7==0)
    {
        cout<<i<<",";
    }
 }
 */

    return 0;
}


    