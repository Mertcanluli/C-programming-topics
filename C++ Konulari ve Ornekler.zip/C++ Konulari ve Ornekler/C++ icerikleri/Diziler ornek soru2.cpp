#include<iostream>
#include<math.h>

using namespace std;

int main()
{
    int a[8]={2,5,9,22,46,65,61,55};
    int toplam=0;
    int carpim=1;
    int tektoplam=0;
    int teksayisayisi=0;
    int enbuyuk=0;
    int enkucuk=0;

    for(int i=0; i<8; i++)
    {
        toplam=toplam+a[i];
        if(a[i]%2==1)
        {
            tektoplam=tektoplam+a[i];
            teksayisayisi++;
        }

        if(a[i]%2==0)
        {
            if(enbuyuk<a[i])
            {
                enbuyuk=a[i];
            }
        }

        if(enkucuk>a[i])
        {
            enkucuk=a[i];
        }

        carpim=carpim*a[i];
    }

    cout<< "Toplam= " << toplam << endl;
    cout<< "Ortalama= " << (float)toplam/8 << endl;
    cout<<"Geometrik Ortalama= "<< pow(carpim,(float)(1/8)) << endl;
    cout<< "Tek sayilarin toplami= " << tektoplam << endl;
    cout<< "Tek sayilarin ortalamasi= " << (float)tektoplam/teksayisayisi << endl;
    cout<< "En buyuk ve en kucuk cift sayilarin toplami= " << (float)(enbuyuk+enkucuk)/2 << endl;
    return 0;
}