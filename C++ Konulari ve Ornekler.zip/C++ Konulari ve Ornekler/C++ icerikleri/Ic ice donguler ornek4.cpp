#include<iostream>

using namespace std;

/*int main()
{
    // yıldızlar ile dik üçgen yapan kodu yazınız.

    cout<<"Sayi Giriniz: "<<endl;
    int n;
    cin>>n;

    for(int i=0; i<n; i++) // basamak sayısı için döngü
    {
        for(int j=0; j<i+1; j++) // yıldız sayısı için döngü
        {
            cout<<"*";
        }
        cout<<endl;
    }
    return 0;
    {
    */

   // yukarıdaki üçgenin ters görüntüsünü yapan kodu yazınız.

   int main()
   {
    cout<<"Sayi Giriniz: "<<endl;
    int n;
    cin>>n;

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n-(i-1); j++) // boşluk için yapılan döngü
        {
            cout<< " ";
        }
        for(int k=0; k<i+1; k++) // yıldız için yapılan döngü
        {
            cout<<"*";
        }
        cout<<endl;
    }

    return 0;

   }
