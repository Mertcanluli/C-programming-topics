#include<iostream>

using namespace std;
int main()

{
    cout<<"Hello World"<<endl;
    cout<<"Ben Mert Can LULI"<<endl;

    return 0;
}

// "#include<iostream>" kütüphanesi temel fonksiyonları içerir. Örnek olarak "int main()"...

// "using namespace std" yazarak belirli satılarda kullanılacak olan "std::" yazılmasının önüne geçer...

// "cout" ekrana yazdırmak için kullanılır... 