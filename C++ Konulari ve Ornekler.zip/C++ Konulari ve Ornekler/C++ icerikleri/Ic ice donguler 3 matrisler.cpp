#include <iostream>

using namespace std;

int main()
{
    // 0001    i=0  j=3
    // 0010    i=1  j=2
    // 0100    i=2  j=1
    // 1000    i=3  j=0        şeklinde olan matrisi kodlayın.


    int b;
    cout<< "Boyut Giriniz: "<<endl;
    cin>>b;

    for(int i=0; i<b; i++)
    {
        for(int j=0; j<b; j++)
        {
            if(i+j==b-1)  // bu koşul ters olan için, düz istersek bunu if(i==j) yaparız.
            cout<< "1";
            else
            cout<< "0";
        }
        cout<<endl;
    }















    return 0;

}

