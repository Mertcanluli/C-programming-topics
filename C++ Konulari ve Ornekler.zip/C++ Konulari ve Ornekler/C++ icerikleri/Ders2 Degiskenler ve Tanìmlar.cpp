#include<iostream>

using namespace std;

int main()
{
    int a; // değişken tipi , değişken adı.
    a=10; // değişkenin değeri

    cout<< a << endl;

    a=20; // "a" değişkenine 20 değeri atandı.

    cout<< a << endl;

    cout<<"Mert Can LULI "<< a << endl;

    int b=30;
    int c=50;
    int d=85;
    int x=2,y=10; // x adında değişken tanımla ve 2 değerini ver ve y değişkeni tanımla ve 10 değerini ver.

    cout<< b << endl;
    cout<< c << endl;
    cout<< d << endl;
    cout<< x << endl;
    cout<< y << endl;
}