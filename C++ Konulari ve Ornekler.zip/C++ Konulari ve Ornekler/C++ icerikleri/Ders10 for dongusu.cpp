#include<iostream>

using namespace std;

int main()
{

    int i;
     for(i=0;i<10;i++) // i sıfırdan başlasın 10 a kadar birer birer artsın koşulu.
     {
        cout<<"Merhaba Dunya"<<endl;
     }

    return 0;
}

// while döngüsü ile farkı satır sayısı olabilir. while daha uzun, for daha kısa satırda yazılır.
