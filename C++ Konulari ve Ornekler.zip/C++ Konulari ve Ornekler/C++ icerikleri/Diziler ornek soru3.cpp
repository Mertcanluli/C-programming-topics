#include<iostream>

using namespace std;

int main()
{
    int n;

    cout<< "Rakam sayisi giriniz: " << endl;
    cin>>n;

    int a[n];

    for(int i=0; i<n; i++)
    {
        cin>>a[i];
    }

    int toplam=0;

    for(int i=0; i<n; i++)
    {
        toplam=toplam+a[i];
    }

    cout<<"Toplam: "<<toplam<< endl;

    return 0;
}