#include<iostream>

using namespace std;

int main()
{
    // Kullanıcıdan bir sayı alıp verilen sayı kadar sayıyı okuyunuz. Bu sayıların içerisindeki +, -, 0 ları oranlayın.

    int n;
    cout<<"Lutfen kac sayi gireceginizi yaziniz: "<< endl;
    cin>>n;

    int esayi=0, asayi=0, ssayi=0;

    for(int i=0; i<n; i++)
    {
        int g; //geçici olarak döngüde okunan sayi
        cin>>g;

        if(g>0)
        asayi++;

        else if(g<0)
        esayi++;

        else
        ssayi++;
    }

    cout<<"Pozitifler: "<<(float)asayi/n<<endl;
    cout<<"Eksiler: "<<(float)esayi/n<<endl;
    cout<<"Sifirlar: "<<(float)ssayi/n<<endl;

    return 0;
}