#include<iostream>

using namespace std;

int main()
{
    int a[5];
    for(int i=0; i<5; i++)
    {
        cin>>a[i];
    }

    int eb= a[0];
    for(int i=1; i<5; i++)
    {
        if(a[i]>eb)
        {
            eb=a[i];
        }
    }
    cout << "En buyuk: " << eb << endl;

    int ek= a[0];
    for(int i=1; i<5; i++)
    {
        if(a[i]<ek)
        {
            ek=a[i];
        }
    }
    cout<< "En kucuk: " << ek << endl;

    int toplam=0;

    for(int i=0; i<5; i++)
    {
        toplam=toplam+a[i];
    }
    cout<< "Toplam: " << toplam << endl;
    cout<< "Ortalama: " << (float)toplam/5 << endl;
    
    return 0;
}