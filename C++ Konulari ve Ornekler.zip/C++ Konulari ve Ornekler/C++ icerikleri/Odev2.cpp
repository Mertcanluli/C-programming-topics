#include<iostream>

using namespace std;

int main()
{
    int x,y;

    cout<<"Birinci Sayiyi Giriniz: ";
    cin>>x;

    cout<<"Ikinci Sayiyi Giriniz: ";
    cin>>y;

    cout<<"Toplam: "<< x+y <<endl;
    cout<<"Cikarma: "<< x-y <<endl;
    cout<<"Carpma: "<< x*y <<endl;
    cout<<"Bolum: "<< (float) x/y <<endl;
    cout<<"Kalan: "<< x%y <<endl;

    return 0;

}