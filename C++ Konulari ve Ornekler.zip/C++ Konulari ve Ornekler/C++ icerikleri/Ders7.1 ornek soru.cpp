#include<iostream>

using namespace std;

int main()
{
     int a;
    
    cout<<"Lutfen Aldiginiz Puani Giriniz: "<<endl;
    cin>>a;

    if(a<50)
    {
        cout<<"F"<<endl;
    }
    else if(a<70)
    {
        cout<<"C"<<endl;
    }
    else if(a<90)
    {
        cout<<"B"<<endl;
    }
    else if(a>90)
    {
        cout<<"A"<<endl;
    }
 
   

   /*int a;
   cout<<"Lutfen Aldiginiz Puani Giriniz: "<<endl;
   cin>>a;

   if(a>0 && a<50)
   {
    cout<<" Harf Notunuz F"<<endl;
   }
   else if(a>=50 && a<70)
   {
    cout<<"Harf Notunuz C"<<endl;
   }
   else if(a>=70 && a<90)
   {
    cout<<"Harf Notunuz B"<<endl;
   }
   else if(a>=90 && a<=100)
   {
    cout<<"Harf Notunuz A"<<endl;
   }
   */

 return 0;
}