#include<iostream>

using namespace std;

int main()
{
    int a,b,c;

    cout<<"Birinci Sayiyi Giriniz: "<<endl;
    cin>>a;

    cout<<"Ikinci Sayiyi Giriniz: "<<endl;
    cin>>b;

    cout<<"Ucuncu Sayiyi Giriniz: "<<endl;
    cin>>c;

    // a, b ve c degeri arasındadır.

    if(a>b && a<c || a>c && a<b) // (b ----- a -----c)  |  (c ----- a -----b)
    {
        cout<<"a, b ve c arasinda bir degerdir."<<endl;
    }
    else
    {
        cout<<"a, b ve c arasinda deger degildir."<<endl;
    }

    // a, b ye eşit ve aynı zamanda c den küçüktür.

    if(a==b && a<c)
    {
        cout<<"a, b ye esittir ve c den kucuktur."<<endl;
    }
    else
    {
        cout<<"a, b ye esit degildir veya c den kucuk degildir."<<endl;
    }

    // a nın b veya c den büyük olup olmadığını kontrol edelim.

    if(a>b || a>c)
    {
        cout<<"a, b veya c den buyuktur."<<endl;
    }
    else
    {
        cout<<"a, b veya c den buyuk degildir veya esittir."<<endl;
    }

    // Üç sayının birbirine eşit olup olmadığı kontrol edelim.

    if(a==b && a==c)
    {
        cout<<"Uc sayida birbirine esittir."<<endl;
    }
    else
    {
        cout<<"Uc sayi birbirine esit degildir."<<endl;
    }




    return 0;
}