#include<iostream>

using namespace std;

int main()
{
    int a;
    a=10;
    cout<< a <<endl;

    a++; // a değerini bir arttır anlamına gelir... (postfix)
    cout<< a <<endl;

    ++a; // a değerini bir arttırır... (prefix)
    cout<< a <<endl;

    int b=20;
    cout<< a+b <<endl;
    cout<< 10+20*2 <<endl; // bu işlemde işlem önceliği söz konusudur... (20*2=40+10=50)

    cout<< 15%2 <<endl; // remainder, modulo (15/2=7.5     15%2=1  33%10=3  7%5=2)

    a--;
    cout<< a <<endl; // a degerini 1 azalt...

    a=a-1;
    cout<< a <<endl;

    cout<< a++ <<endl; // ekrana 10 basılır fakat hafızada 11 olur...
    cout<< ++a <<endl; // a nın degeri önce bir artar sonra ekrana yazılır...

    int x;
    x=10;

    x=x-1;
    x--;
    --x;
    x-=1;
    x+=5; // x=x+5

    cout<< x <<endl;

    x*=2; //x*2=x
    cout<< x <<endl;
    
return 0;

}