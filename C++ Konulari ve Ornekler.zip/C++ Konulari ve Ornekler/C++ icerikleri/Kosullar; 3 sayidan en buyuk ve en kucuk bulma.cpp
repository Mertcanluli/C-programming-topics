#include<iostream>

using namespace std;

int main()
{
    int x,y,z;

    cout<<"Birinci sayiyi giriniz: "<<endl;
    cin>>x;

    cout<<"Ikinci sayiyi giriniz: "<<endl;
    cin>>y;

    cout<<"Ucuncu sayiyi giriniz: "<<endl;
    cin>>z;

    if(x>y && x>z)
    {
        cout<<"En Buyuk: "<<"x"<<endl;
        if(y>z)
        {
            cout<<"En kucuk: "<<"z"<<endl;
        }
        else
        {
            cout<<"En kucuk: "<<"y"<<endl;
        }
    }

    if(y>x && y>z)
    {
        cout<<"En buyuk: "<<"y"<<endl;
        if(x>z)
        {
            cout<<"En kucuk: "<<"z"<<endl;
        }
        else
        {
            cout<<"En kucuk: "<<"x"<<endl;
        }
    }

    if(z>x && z>y)
    {
        cout<<"En buyuk: "<<"z"<<endl;
        if(y>x)
        {
            cout<<"En kucuk: "<<"x"<<endl;
        }
        else
        {
            cout<<"En kucuk: "<<"y"<<endl;
        }
    }

   /*int enbuyuk=x;
    if(y>enbuyuk)
    y=enbuyuk;
    if(z>enbuyuk)
    z=enbuyuk;

    int enkucuk=x;
    if(y<enkucuk)
    y=enkucuk;
    if(z<enkucuk)
    z=enkucuk;

    cout<<"En buyuk: "<<enbuyuk<<endl;
    cout<<"En kucuk: "<<enkucuk<<endl;
    */


    return 0;
}