#include<iostream>

using namespace std;

int main()
{
    int a;
    a=1;

    while(a<=10) // a değeri 10 dan küçük veya 10 a eşit olduğu sürece
    {
        cout<<"MERHABA"<<endl; // Ekrana MERHABA yazdır.
        a++; // a değerini bir bir arttır. Eğer bunu yazmasaydık sonsuz döngü şeklinde çalışırdı.
    }

    return 0;
}
