#include<iostream>

using namespace std;

int f(int x){
    cout<< x <<endl;
}

int main()
{
    f(15);
    f(39);
}

// int mainden önce tanımlanan fonksiyon sayesinde int main içinde tekrardan cout<< input << endl; yazmadan fonksiyon çalıştı.
