#include<iostream>

using namespace std;

int main()
{
    int a;
    a=10;
    cout<< a << endl;

    float b;
    b=15.98;
    cout<< b << endl;

    long tl;
    tl=123456789;
    cout<< tl << endl;

    char c;
    c='m';
    cout<< c << endl;

    return 0;
}