#include<iostream>
#include<math.h>

using namespace std;

int main()
{
    int kacgun,kacisci;

    cout<<"Bir isci isi kac gunde bitirebilir?"<<endl;
    cin>>kacgun;

    cout<<"Toplam kac kisi calisacak?"<<endl;
    cin>>kacisci;

    cout<<"Bitirme suresi: "<< kacgun/kacisci <<" gundur "<<endl;
    

      /*int a,b,c;

      cout<<"a uzunlugunu giriniz: "<<endl;
      cin>>a;

      cout<<"b uzunlugunu giriniz: "<<endl;
      cin>>b;

      c=sqrt(a*a+b*b);

      cout<<"hipotenus="<< c <<endl;
      cout<<"Cevresi: "<< a+b+c <<endl;
      cout<<"Alani: "<< (a*b)/2 <<endl;
      */

     /*int yol,hiz;

     cout<<"Mesafeyi giriniz: "<<endl;
     cin>>yol;

     cout<<"Hizini giriniz: "<<endl;
     cin>>hiz;

     cout<<"Tahmini varis sureniz: "<< yol/hiz ;

     int saat= yol/hiz; //3.33 -> 3

     float dakikaismi= (float)yol/hiz - yol/hiz; // ondalıklı kısmı almak için yapıldı

     int dakika= dakikaismi*60; // float değeri 60 ile çarpılıp dakikaya çevrildi.

     cout<< " Saat " << dakika << " dakikadir."<<endl;
     */

    /*int a,b,c;

    cout<<"Dik ucgenin kenarlarini giriniz: "<<endl;
    
    cin>>a;
    cin>>b;
    cin>>c;

    if(a*a+b*b==c*c || b*b+c*c==a*a || a*a+c*c==b*b)
    {
        cout<<"Dik ucgendir."<<endl;
    }
    else
    {
        cout<<"Dik ucgen degildir."<<endl;
    }
    */
 
    return 0;
}