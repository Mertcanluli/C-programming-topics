#include<iostream>

using namespace std;

int main()
{
    int x[3]={1,2,3};

    int *q;
         
    q=x; // q=&x[0] aynı anlama gelirrr...

    cout<< q[2] << endl; // dizideki 2. elemanı yani " 3 " değerini bastırır...

    q[2]=8; // x dizisindeki 2. elemana 8 değerini atadık...

    cout<< x[2] << endl; // x dizisindeki 2. eleman yani yeni değer olan 8 ekrana basılır...

    return 0;
}