#include<iostream>

using namespace std;

int main()
{
    // 1 den 10 a kadar olan ardışık rakamları bastıran kodu yazınız.

    for(int i=1; i<=10; i++)
    {
        cout<< i << endl;
    }
    

    // 100 den 0 a kadar 13 e tam bölünen sayıların ekrana bastırılma kodu.

    /*for(int i=100; i>0; i--)
    {
        if(i%13==0)
        {
            cout<< i <<endl;
        }
    }
    */

   // 1. Kolonda 1 den 100 e kadar olan 15 in katları
   // 2. Kolonda 1 den 30 a kadar olan 5 in katları
   // 3. Kolonda 100 den 50 ye kadar olan 10 un katları
   // 4. Kolonda 2 den 64 e kadar olan 2 in üstleri ni yazan kodu yazınız...

   /*int i=15;
   int j=5;
   int k=100;
   int l=2;

   while(i<100)
   {
    cout<< i << "\t" << j << "\t" << k << "\t" << l << endl; // \t arada 3-4 boşluk bırakır.

    i+=15;
    j+=5;
    k-=10;
    l*=2;

   }
   */

    return 0;
}