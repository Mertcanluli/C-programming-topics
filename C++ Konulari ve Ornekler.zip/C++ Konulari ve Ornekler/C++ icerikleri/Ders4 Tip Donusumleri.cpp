#include<iostream>

using namespace std;

int main()
{
    int a;
    a=10;
    cout<< a << endl;

    float pi;
    pi=3.14;
    cout<< pi << endl;

    long tl;
    tl=123456789;
    cout<< tl << endl;

    char c;
    c='G'; // 71--> ASCII TABLE
    cout<< c << endl;

    int cc=c;
    cout<< cc << endl;

    int ipi=pi;
    cout<< ipi << endl;

    float x= 4.99;
    int abc=x;
    cout<< abc << endl;

    int birsayi=56;
    float fbirsayi=birsayi;
    cout<< fbirsayi << endl;

    int at=64;
    char cat=at;  // ASCII TABLE
    cout<< cat << endl;

    cout<< (char) at << endl; // type casting. farklı formatta tip dönüşümü...
    cout<< (char) 100 << endl;

    return 0;
}