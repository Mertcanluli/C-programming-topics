#include<iostream>

using namespace std;

int main()
{
    int a=10;

    if(a>=20) // <= (kucuk eşittir), < (küçüktür), >= (büyük eşittir), > (büyüktür), != (eşit değildir), ==(eşittir)
    { //boolean: True or False
        cout<<"a 20 den buyuktur"<<endl;
    }
    else if(a==20)
    {
        cout<<"a 20 ye esittir"<<endl;
    }
    else if(a!=15)
    {
        cout<<"a 15 e esit degildir"<<endl;
    }
    else
    {
        cout<<"a 20 den kucuk"<<endl;
    }
  
  return 0;
}