#include<iostream>

using namespace std;

int main()
{
    int a=10;
    cout<< a <<endl;

    cin>>a;

    cout<<"Klavyeden "<< a << " degerini girdiniz"<<endl;
    cout<<"Klavyeden girilen degerin 10 fazlasi "<<a+10<<endl;

    return 0;
    
}